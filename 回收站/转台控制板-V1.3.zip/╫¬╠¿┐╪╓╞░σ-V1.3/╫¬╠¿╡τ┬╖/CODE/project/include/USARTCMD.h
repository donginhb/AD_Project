#ifndef USARTCMD_H
#define USARTCMD_H
extern void DealUsartCMD(uint8_t *buf);
#endif  
